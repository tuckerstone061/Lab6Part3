/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package composite;

/**
 *
 * @author tucker.stone061
 */
public class TrueFalse implements Test{
    public void draw(String type) {
        System.out.println("Draw a new true/false test.");
    }
}
